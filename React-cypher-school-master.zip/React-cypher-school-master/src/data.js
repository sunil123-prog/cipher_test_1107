import pianoPic from './assets/piano.jpg';

const data = [
    { name: 'Nord Stage 3 88 keys', img: pianoPic, perks: ['brand new', 'free shipping', '15%off'], vendorName: 'EMLA Music', vendorAddress: 'Le Havre, France', rating: { number: 31, value: 5 }, price: 5738, shipping: 195, },
    { name: 'item 2', img: pianoPic, perks: ['brand new', 'free shipping', '15%off'], vendorName: 'EMLA Music', vendorAddress: 'Le Havre, France', rating: { number: 31, value: 5 }, price: 5738, shipping: 195, },
    { name: 'item 2', img: pianoPic, perks: ['brand new', 'free shipping', '15%off'], vendorName: 'EMLA Music', vendorAddress: 'Le Havre, France', rating: { number: 31, value: 5 }, price: 5738, shipping: 195, },
    { name: 'item 2', img: pianoPic, perks: ['brand new', 'free shipping', '15%off'], vendorName: 'EMLA Music', vendorAddress: 'Le Havre, France', rating: { number: 31, value: 5 }, price: 5738, shipping: 195, },
    { name: 'item 2', img: pianoPic, perks: ['brand new', 'free shipping', '15%off'], vendorName: 'EMLA Music', vendorAddress: 'Le Havre, France', rating: { number: 31, value: 5 }, price: 5738, shipping: 195, },
]

export default data